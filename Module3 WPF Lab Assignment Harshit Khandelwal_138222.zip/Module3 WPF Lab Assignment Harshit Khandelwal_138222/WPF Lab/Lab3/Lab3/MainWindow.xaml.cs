﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Text.RegularExpressions;

namespace Lab3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

         public void Clear()
        {
            txtName.Text = String.Empty;
            psbPassword.Clear();


        }


        int count = 0;

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {

            count = count + 1;
            Window1 wind1 = new Window1();
            if(txtName.Text=="admin" && psbPassword.Password == "admin")
            {
                wind1.Show();
                this.Close();
                
            }
            else if(count<=3)
            {
              
                MessageBox.Show("Please enter valid User Name and Password.");
                Clear();
            }
            else if (count > 3)
            {
                this.Close();
            }
        }

        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }


        private void txtName_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (Regex.IsMatch(e.Text, "[0-9]"))
            {
                e.Handled = true;
            }

        }
    }
}
    

