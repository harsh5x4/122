﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Lab3
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
          public Window1()
        {
            InitializeComponent();
            listBox.DataContext = pt;
            //data.DataContext = pt;
        }
        List<Patient> pt = new List<Patient>();//patient list
        Patient ob1;
        private void button_Click(object sender, RoutedEventArgs e)
        {
            ob1 = new Patient();
            ob1.PatientID = Convert.ToInt32(idbox.Text);
            ob1.Patient_Name = Convert.ToString(namebox.Text);
            if (Convert.ToString(typebox.Text) == "IN")
                ob1.Patient_Type =PatientType.IN;
            else
                ob1.Patient_Type = PatientType.OUT;

           pt.Add(ob1);
         
           // data.Items.Refresh();
           listBox.Items.Refresh();
            control.SelectedIndex = 1;
           
        }

    }
    public enum PatientType
    {
        IN,OUT
    }
    public class Patient
    {
        public int PatientID { get; set; }
        public string Patient_Name { get; set; }
        public PatientType Patient_Type { get; set; }
    }
}

       
           